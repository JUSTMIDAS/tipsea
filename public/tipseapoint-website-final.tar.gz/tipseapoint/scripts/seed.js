/**
 * TipSea Point — Database Seed Script
 * Run: node scripts/seed.js
 */
require('dotenv').config({ path: '../.env' });
const mongoose = require('mongoose');
const path = require('path');

// Load models from parent directory
const Review = require(path.join(__dirname, '../models/Review'));
const Booking = require(path.join(__dirname, '../models/Booking'));
const BlockedDate = require(path.join(__dirname, '../models/BlockedDate'));

const MONGO_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/tipseapoint';

const sampleReviews = [
  {
    guestName: 'Catherine & Michael M.',
    guestLocation: 'New York, USA',
    rating: 5,
    title: 'The most peaceful place on Earth',
    content: 'Walking out each morning to that view — water in every direction, silence except for the waves — it is the most at-peace we have ever felt on a vacation. The sunset from the tip of the property on our last night brought us both to tears.',
    stayDate: new Date('2024-03-15'),
    approved: true,
    featured: true,
  },
  {
    guestName: 'David & Sarah K.',
    guestLocation: 'London, UK',
    rating: 5,
    title: 'Unmatched in the Caribbean',
    content: 'The putting green at sunset is something I will talk about forever. The host arranged fresh conch for dinner three nights running. We have stayed at luxury properties across the world — TipSea Point is in a category of its own.',
    stayDate: new Date('2024-02-20'),
    approved: true,
    featured: true,
  },
  {
    guestName: 'Marcus R.',
    guestLocation: 'Toronto, Canada',
    rating: 5,
    title: 'Worth every single penny',
    content: 'We rented luxury properties across the Caribbean for twenty years. TipSea Point is in its own category entirely. The location alone — two oceans meeting at your doorstep — is something photographs simply cannot capture.',
    stayDate: new Date('2024-01-10'),
    approved: true,
    featured: false,
  },
  {
    guestName: 'The Henderson Family',
    guestLocation: 'Houston, Texas',
    rating: 5,
    title: 'Our kids talk about it every single day',
    content: 'Three kids, two weeks, zero complaints. The property has everything a family needs and the privacy means the children could run free all day. The bonefish guide arranged for us was extraordinary — even our 10-year-old caught one.',
    stayDate: new Date('2023-12-28'),
    approved: true,
    featured: false,
  },
  {
    guestName: 'Isabelle L.',
    guestLocation: 'Paris, France',
    rating: 5,
    title: 'A dream that became real',
    content: 'I have dreamed of a place exactly like this my entire life. The light in the Bahamas does something to you — and TipSea Point captures all of it. The dock at sunrise, the sound of the reef at night. We will return every year.',
    stayDate: new Date('2024-04-05'),
    approved: true,
    featured: true,
  },
  {
    guestName: 'James & Caroline P.',
    guestLocation: 'Sydney, Australia',
    rating: 5,
    title: 'The trip of our lifetime',
    content: 'We flew twenty-four hours for this and it was absolutely worth every moment. The host was exceptional — arranging a sunset sailing charter, stocking the kitchen with our dietary preferences, and leaving a handwritten welcome note. Pure class.',
    stayDate: new Date('2024-01-22'),
    approved: true,
    featured: false,
  },
];

async function seed() {
  try {
    await mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });
    console.log('✅ Connected to MongoDB:', MONGO_URI);

    // Clear existing
    await Review.deleteMany({});
    await Booking.deleteMany({});
    await BlockedDate.deleteMany({});
    console.log('🗑️  Cleared existing data');

    // Seed reviews
    await Review.insertMany(sampleReviews);
    console.log(`⭐  Seeded ${sampleReviews.length} reviews`);

    // Seed a sample confirmed booking
    const booking = new Booking({
      guestName: 'James Whitmore',
      guestEmail: 'james.whitmore@example.com',
      guestPhone: '+1 (305) 555-0192',
      guestCountry: 'United States',
      checkIn: new Date('2025-08-10'),
      checkOut: new Date('2025-08-18'),
      adults: 4,
      children: 2,
      pricePerNight: 1200,
      status: 'confirmed',
      specialRequests: 'Please arrange a private chef for the first evening. We celebrate an anniversary on the 14th.',
      paymentStatus: 'deposit_paid',
    });
    await booking.save();

    // Block those dates
    const datesToBlock = [];
    const cur = new Date('2025-08-10');
    const end = new Date('2025-08-18');
    while (cur < end) {
      datesToBlock.push({ date: new Date(cur), reason: 'booked', bookingId: booking._id });
      cur.setDate(cur.getDate() + 1);
    }
    await BlockedDate.insertMany(datesToBlock);

    console.log('📅  Seeded 1 confirmed booking (Aug 10–18 2025) + blocked dates');
    console.log('\n🌊  Seed complete! TipSea Point database is ready.');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('Admin login: admin@tipseapoint.com / admin123');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
  } catch (err) {
    console.error('❌ Seed error:', err.message);
  } finally {
    await mongoose.disconnect();
  }
}

seed();
