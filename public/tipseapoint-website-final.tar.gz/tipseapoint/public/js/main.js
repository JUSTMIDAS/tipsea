/**
 * TipSea Point — main.js
 * Custom cursor · Ambient particles · Scroll progress
 * GSAP counters · Marquee · Enhanced interactions
 */

'use strict';

/* ════════════════════════════════════════════════
   SITE LOADER
   ════════════════════════════════════════════════ */
function initLoader() {
  const loader = document.getElementById('siteLoader');
  if (!loader) return;

  window.addEventListener('load', () => {
    setTimeout(() => {
      loader.classList.add('hidden');
    }, 800);
  });

  // Fallback: hide after 3s
  setTimeout(() => {
    if (loader) loader.classList.add('hidden');
  }, 3000);
}

/* ════════════════════════════════════════════════
   CUSTOM CURSOR
   ════════════════════════════════════════════════ */
function initCursor() {
  if (window.matchMedia('(max-width: 768px)').matches) return;

  const dot  = document.querySelector('.cursor-dot');
  const ring = document.querySelector('.cursor-ring');
  if (!dot || !ring) return;

  let mx = 0, my = 0;
  let rx = 0, ry = 0;

  document.addEventListener('mousemove', (e) => {
    mx = e.clientX;
    my = e.clientY;
    dot.classList.add('visible');
    ring.classList.remove('hidden');
    ring.classList.add('visible');
    dot.style.left  = mx + 'px';
    dot.style.top   = my + 'px';
  });

  document.addEventListener('mouseleave', () => {
    dot.classList.remove('visible');
    ring.classList.add('hidden');
  });

  // Smooth ring follow
  function animateRing() {
    rx += (mx - rx) * 0.12;
    ry += (my - ry) * 0.12;
    ring.style.left = rx + 'px';
    ring.style.top  = ry + 'px';
    requestAnimationFrame(animateRing);
  }
  animateRing();

  // Expand on interactive elements
  const interactives = document.querySelectorAll('a, button, .feature-card, .gallery-item, .room-card, .faq-q');
  interactives.forEach(el => {
    el.addEventListener('mouseenter', () => {
      ring.style.width  = '52px';
      ring.style.height = '52px';
      ring.style.borderColor = 'rgba(0,180,216,0.9)';
      dot.style.transform = 'translate(-50%,-50%) scale(0.5)';
    });
    el.addEventListener('mouseleave', () => {
      ring.style.width  = '32px';
      ring.style.height = '32px';
      ring.style.borderColor = 'rgba(0,180,216,0.5)';
      dot.style.transform = 'translate(-50%,-50%) scale(1)';
    });
  });
}

/* ════════════════════════════════════════════════
   AMBIENT PARTICLES
   ════════════════════════════════════════════════ */
function initParticles() {
  const canvas = document.getElementById('heroParticles');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  let W = canvas.width  = canvas.offsetWidth;
  let H = canvas.height = canvas.offsetHeight;

  window.addEventListener('resize', () => {
    W = canvas.width  = canvas.offsetWidth;
    H = canvas.height = canvas.offsetHeight;
  });

  const particles = [];
  const COUNT = 55;

  for (let i = 0; i < COUNT; i++) {
    particles.push({
      x: Math.random() * W,
      y: Math.random() * H,
      r: Math.random() * 1.5 + 0.3,
      vx: (Math.random() - 0.5) * 0.3,
      vy: (Math.random() - 0.5) * 0.2 - 0.15,
      alpha: Math.random() * 0.5 + 0.1,
    });
  }

  function draw() {
    ctx.clearRect(0, 0, W, H);
    particles.forEach(p => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(0, 180, 216, ${p.alpha})`;
      ctx.fill();

      p.x += p.vx;
      p.y += p.vy;

      if (p.y < -5)  p.y = H + 5;
      if (p.x < -5)  p.x = W + 5;
      if (p.x > W+5) p.x = -5;
    });
    requestAnimationFrame(draw);
  }
  draw();
}

/* ════════════════════════════════════════════════
   SCROLL PROGRESS BAR
   ════════════════════════════════════════════════ */
function initScrollProgress() {
  const bar = document.getElementById('scrollProgress');
  if (!bar) return;

  window.addEventListener('scroll', () => {
    const scrollTop  = window.scrollY;
    const docHeight  = document.documentElement.scrollHeight - window.innerHeight;
    const progress   = docHeight > 0 ? scrollTop / docHeight : 0;
    bar.style.transform = `scaleX(${progress})`;
  }, { passive: true });
}

/* ════════════════════════════════════════════════
   FLOATING CTA
   ════════════════════════════════════════════════ */
function initFloatingCta() {
  const cta = document.getElementById('floatingCta');
  if (!cta) return;

  let heroBottom = 0;

  function measureHero() {
    const hero = document.getElementById('hero');
    if (hero) heroBottom = hero.offsetTop + hero.offsetHeight;
  }
  measureHero();
  window.addEventListener('resize', measureHero, { passive: true });

  window.addEventListener('scroll', () => {
    const scrollY = window.scrollY;
    const nearBottom = scrollY + window.innerHeight > document.body.scrollHeight - 400;
    if (scrollY > heroBottom && !nearBottom) {
      cta.classList.add('visible');
    } else {
      cta.classList.remove('visible');
    }
  }, { passive: true });
}

/* ════════════════════════════════════════════════
   COUNTER ANIMATION
   ════════════════════════════════════════════════ */
function animateCounter(el, target, suffix = '') {
  let start = 0;
  const duration = 1800;
  const step = (timestamp) => {
    if (!start) start = timestamp;
    const progress = Math.min((timestamp - start) / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
    el.textContent = Math.floor(eased * target) + suffix;
    if (progress < 1) requestAnimationFrame(step);
    else el.textContent = target + suffix;
  };
  requestAnimationFrame(step);
}

function initCounters() {
  const counters = document.querySelectorAll('[data-counter]');
  if (!counters.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting && !entry.target.dataset.counted) {
        entry.target.dataset.counted = 'true';
        const target = parseInt(entry.target.dataset.counter, 10);
        const suffix = entry.target.dataset.suffix || '';
        animateCounter(entry.target, target, suffix);
      }
    });
  }, { threshold: 0.5 });

  counters.forEach(c => observer.observe(c));
}

/* ════════════════════════════════════════════════
   MARQUEE DUPLICATION
   ════════════════════════════════════════════════ */
function initMarquee() {
  const inner = document.querySelector('.marquee-inner');
  if (!inner) return;
  // Duplicate content for infinite scroll
  inner.innerHTML += inner.innerHTML;
}

/* ════════════════════════════════════════════════
   GALLERY LIGHTBOX
   ════════════════════════════════════════════════ */
function initLightbox() {
  const overlay = document.getElementById('lightboxOverlay');
  const img     = document.getElementById('lightboxImg');
  const close   = document.getElementById('lightboxClose');
  if (!overlay || !img) return;

  document.querySelectorAll('.gallery-item img').forEach(el => {
    el.style.cursor = 'zoom-in';
    el.addEventListener('click', () => {
      img.src = el.src.replace(/w=\d+/, 'w=1600');
      overlay.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  });

  function closeLightbox() {
    overlay.classList.remove('open');
    document.body.style.overflow = '';
    img.src = '';
  }

  if (close) close.addEventListener('click', closeLightbox);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) closeLightbox(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeLightbox(); });
}

/* ════════════════════════════════════════════════
   GSAP PARALLAX (extra depth)
   ════════════════════════════════════════════════ */
function initParallaxItems() {
  if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') return;

  // Floating accent images in story section
  gsap.to('.story-img-accent', {
    yPercent: -12,
    ease: 'none',
    scrollTrigger: {
      trigger: '#story',
      start: 'top bottom',
      end: 'bottom top',
      scrub: 1.2,
    }
  });

  // Staggered feature cards entrance
  gsap.fromTo('.feature-card', {
    opacity: 0,
    y: 40,
    scale: 0.97,
  }, {
    opacity: 1,
    y: 0,
    scale: 1,
    duration: 0.7,
    stagger: 0.1,
    ease: 'power2.out',
    scrollTrigger: {
      trigger: '.features-grid',
      start: 'top 82%',
      toggleActions: 'play none none none',
    }
  });

  // Room cards stagger
  gsap.fromTo('.room-card', {
    opacity: 0,
    y: 35,
  }, {
    opacity: 1,
    y: 0,
    duration: 0.75,
    stagger: 0.15,
    ease: 'power2.out',
    scrollTrigger: {
      trigger: '.rooms-grid',
      start: 'top 82%',
      toggleActions: 'play none none none',
    }
  });

  // Review cards stagger
  gsap.fromTo('.review-card', {
    opacity: 0,
    y: 30,
  }, {
    opacity: 1,
    y: 0,
    duration: 0.65,
    stagger: 0.12,
    ease: 'power2.out',
    scrollTrigger: {
      trigger: '#reviews',
      start: 'top 80%',
      toggleActions: 'play none none none',
    }
  });

  // Animated section numbers / line-grows
  document.querySelectorAll('.line-grow').forEach(el => {
    ScrollTrigger.create({
      trigger: el,
      start: 'top 88%',
      onEnter: () => el.classList.add('grown'),
    });
  });
}

/* ════════════════════════════════════════════════
   FORM VALIDATION HELPERS
   ════════════════════════════════════════════════ */
function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function highlightInvalid(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.style.borderColor = '#ef4444';
  el.addEventListener('input', () => {
    el.style.borderColor = '';
  }, { once: true });
}

/* ════════════════════════════════════════════════
   SMOOTH ANCHOR NAVIGATION
   ════════════════════════════════════════════════ */
function initSmoothNav() {
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', (e) => {
      const target = document.querySelector(link.getAttribute('href'));
      if (!target) return;
      e.preventDefault();
      const offset = 80; // nav height
      const top = target.getBoundingClientRect().top + window.scrollY - offset;
      window.scrollTo({ top, behavior: 'smooth' });
    });
  });
}

/* ════════════════════════════════════════════════
   KEYBOARD ACCESSIBILITY
   ════════════════════════════════════════════════ */
function initKeyboard() {
  // Close modals on Escape
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-overlay.open').forEach(m => {
        m.classList.remove('open');
        document.body.style.overflow = '';
      });
    }
  });

  // FAQ keyboard navigation
  document.querySelectorAll('.faq-q').forEach(q => {
    q.setAttribute('tabindex', '0');
    q.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        q.click();
      }
    });
  });
}

/* ════════════════════════════════════════════════
   PERFORMANCE: lazy-load images
   ════════════════════════════════════════════════ */
function initLazyImages() {
  if (!('IntersectionObserver' in window)) return;

  const imgs = document.querySelectorAll('img[loading="lazy"]');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const img = entry.target;
        observer.unobserve(img);
      }
    });
  }, { rootMargin: '200px' });

  imgs.forEach(img => observer.observe(img));
}

/* ════════════════════════════════════════════════
   INIT ALL
   ════════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
  initLoader();
  initCursor();
  initParticles();
  initScrollProgress();
  initFloatingCta();
  initCounters();
  initMarquee();
  initKeyboard();
  initSmoothNav();
  initLazyImages();

  // Parallax & GSAP extras — after GSAP loads
  if (typeof gsap !== 'undefined') {
    initParallaxItems();
  } else {
    window.addEventListener('load', initParallaxItems);
  }

  // Lightbox
  initLightbox();
});
