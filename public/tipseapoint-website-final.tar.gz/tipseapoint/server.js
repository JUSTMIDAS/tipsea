const express  = require('express');
const mongoose = require('mongoose');
const cors     = require('cors');
const helmet   = require('helmet');
const rateLimit = require('express-rate-limit');
const path     = require('path');
require('dotenv').config();

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Security ─────────────────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc:   ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com", "https://cdn.jsdelivr.net"],
      fontSrc:    ["'self'", "https://fonts.gstatic.com"],
      scriptSrc:  ["'self'", "'unsafe-inline'", "https://cdn.jsdelivr.net", "https://cdnjs.cloudflare.com"],
      imgSrc:     ["'self'", "data:", "https://images.unsplash.com", "https://*.unsplash.com"],
      connectSrc: ["'self'"],
    },
  },
}));

app.use(cors({ origin: process.env.ALLOWED_ORIGIN || '*' }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// ── Rate limiting ─────────────────────────────────────────────
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many requests — try again shortly.' },
});
app.use('/api/', apiLimiter);

// ── Static files ──────────────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public'), {
  maxAge: process.env.NODE_ENV === 'production' ? '7d' : 0,
  etag: true,
}));

// ── MongoDB ───────────────────────────────────────────────────
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/tipseapoint')
  .then(() => console.log('✅  MongoDB connected'))
  .catch(err => console.warn('⚠️   MongoDB not connected:', err.message, '\n    (Run `mongod` or set MONGODB_URI in .env)'));

// ── API routes ────────────────────────────────────────────────
app.use('/api/bookings',    require('./routes/bookings'));
app.use('/api/inquiries',   require('./routes/inquiries'));
app.use('/api/availability', require('./routes/availability'));
app.use('/api/reviews',     require('./routes/reviews'));
app.use('/api/admin',       require('./routes/admin'));

// ── Health check ──────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'TipSea Point API',
    timestamp: new Date().toISOString(),
    db: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
  });
});

// ── Named page routes ─────────────────────────────────────────
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// ── SPA fallback → 404 page for unknown routes ────────────────
app.get('*', (req, res) => {
  // API 404
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ success: false, message: 'API endpoint not found' });
  }
  // If it looks like a file request (has extension), serve 404.html with 404 status
  if (path.extname(req.path) && req.path !== '/') {
    return res.status(404).sendFile(path.join(__dirname, 'public', '404.html'));
  }
  // Everything else → main app (for anchor-link deep links)
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ── Global error handler ──────────────────────────────────────
app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  console.error('💥 Unhandled error:', err.message);
  if (req.path.startsWith('/api/')) {
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
  res.status(500).sendFile(path.join(__dirname, 'public', '404.html'));
});

// ── Start ─────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('  🌊  TipSea Point');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(`  Website  →  http://localhost:${PORT}`);
  console.log(`  Admin    →  http://localhost:${PORT}/admin`);
  console.log(`  Health   →  http://localhost:${PORT}/api/health`);
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
});

module.exports = app;
