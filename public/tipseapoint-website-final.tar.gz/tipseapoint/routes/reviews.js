const express = require('express');
const router = express.Router();
const Review = require('../models/Review');

// Get approved reviews
router.get('/', async (req, res) => {
  try {
    const reviews = await Review.find({ approved: true })
      .sort({ featured: -1, createdAt: -1 })
      .limit(12);
    res.json({ success: true, reviews });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Submit a review
router.post('/', async (req, res) => {
  try {
    const review = new Review(req.body);
    await review.save();
    res.status(201).json({
      success: true,
      message: 'Thank you for your review! It will appear after approval.'
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
