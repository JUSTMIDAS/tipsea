const express = require('express');
const router  = express.Router();
const { body, validationResult } = require('express-validator');
const Inquiry = require('../models/Inquiry');
const { sendInquiryConfirmationGuest, sendInquiryAlertAdmin } = require('../middleware/mailer');

router.post('/', [
  body('name').trim().notEmpty().withMessage('Name is required'),
  body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
  body('message').trim().isLength({ min: 10 }).withMessage('Message must be at least 10 characters'),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty())
    return res.status(400).json({ success: false, errors: errors.array() });

  try {
    const inquiry = new Inquiry(req.body);
    await inquiry.save();

    // Fire emails (non-blocking)
    sendInquiryConfirmationGuest(inquiry).catch(e => console.error('Guest email err:', e.message));
    sendInquiryAlertAdmin(inquiry).catch(e => console.error('Admin email err:', e.message));

    res.status(201).json({
      success: true,
      message: 'Thank you! We\'ll be in touch within 24 hours.',
      id: inquiry._id,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
