const express = require('express');
const router = express.Router();
const BlockedDate = require('../models/BlockedDate');

// Get all blocked dates for a month range (for calendar)
router.get('/calendar', async (req, res) => {
  try {
    const { year, month } = req.query;
    const startDate = new Date(year || new Date().getFullYear(), month ? month - 1 : new Date().getMonth(), 1);
    const endDate = new Date(startDate.getFullYear(), startDate.getMonth() + 3, 0);

    const blockedDates = await BlockedDate.find({
      date: { $gte: startDate, $lte: endDate }
    }).select('date reason -_id');

    res.json({
      success: true,
      blockedDates: blockedDates.map(d => ({
        date: d.date.toISOString().split('T')[0],
        reason: d.reason
      }))
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
