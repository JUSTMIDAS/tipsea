const express  = require('express');
const router   = express.Router();
const jwt      = require('jsonwebtoken');
const bcrypt   = require('bcryptjs');
const Booking    = require('../models/Booking');
const Inquiry    = require('../models/Inquiry');
const Review     = require('../models/Review');
const BlockedDate = require('../models/BlockedDate');
const { sendBookingStatusUpdate } = require('../middleware/mailer');

const JWT_SECRET     = process.env.JWT_SECRET || 'tipseapoint-secret-2024';
const ADMIN_EMAIL    = process.env.ADMIN_EMAIL || 'admin@tipseapoint.com';
const ADMIN_PASS_HASH = process.env.ADMIN_PASS_HASH || bcrypt.hashSync('admin123', 10);

// ── Auth middleware ──────────────────────────────────────────
function auth(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ success: false, message: 'No token' });
  try {
    req.admin = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ success: false, message: 'Invalid or expired token' });
  }
}

// ── Login ────────────────────────────────────────────────────
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password)
    return res.status(400).json({ success: false, message: 'Email and password required' });
  if (email !== ADMIN_EMAIL || !bcrypt.compareSync(password, ADMIN_PASS_HASH))
    return res.status(401).json({ success: false, message: 'Invalid credentials' });
  const token = jwt.sign({ email, role: 'admin' }, JWT_SECRET, { expiresIn: '24h' });
  res.json({ success: true, token });
});

// ── Dashboard stats ──────────────────────────────────────────
router.get('/stats', auth, async (req, res) => {
  try {
    const [totalBookings, pendingBookings, totalInquiries, newInquiries, pendingReviews] = await Promise.all([
      Booking.countDocuments(),
      Booking.countDocuments({ status: 'pending' }),
      Inquiry.countDocuments(),
      Inquiry.countDocuments({ status: 'new' }),
      Review.countDocuments({ approved: false }),
    ]);

    const [recentBookings, revenueAgg] = await Promise.all([
      Booking.find().sort({ createdAt: -1 }).limit(5).lean(),
      Booking.aggregate([
        { $match: { status: { $in: ['confirmed', 'completed'] } } },
        { $group: { _id: null, total: { $sum: '$totalPrice' } } },
      ]),
    ]);

    res.json({
      success: true,
      stats: {
        totalBookings, pendingBookings,
        totalInquiries, newInquiries, pendingReviews,
        totalRevenue: revenueAgg[0]?.total || 0,
        recentBookings,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ── All bookings ─────────────────────────────────────────────
router.get('/bookings', auth, async (req, res) => {
  try {
    const { status, page = 1, limit = 25 } = req.query;
    const query    = status ? { status } : {};
    const skip     = (parseInt(page) - 1) * parseInt(limit);
    const [bookings, total] = await Promise.all([
      Booking.find(query).sort({ createdAt: -1 }).skip(skip).limit(parseInt(limit)).lean(),
      Booking.countDocuments(query),
    ]);
    res.json({ success: true, bookings, total, page: parseInt(page), pages: Math.ceil(total / limit) });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ── Update booking ───────────────────────────────────────────
router.patch('/bookings/:id', auth, async (req, res) => {
  try {
    const prev    = await Booking.findById(req.params.id);
    const booking = await Booking.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!booking) return res.status(404).json({ success: false, message: 'Not found' });

    // Send email on status change
    if (req.body.status && req.body.status !== prev.status) {
      sendBookingStatusUpdate(booking).catch(e => console.error('Status email err:', e.message));
    }
    res.json({ success: true, booking });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ── Delete booking ───────────────────────────────────────────
router.delete('/bookings/:id', auth, async (req, res) => {
  try {
    const booking = await Booking.findByIdAndDelete(req.params.id);
    if (!booking) return res.status(404).json({ success: false, message: 'Not found' });
    // Unblock its dates
    await BlockedDate.deleteMany({ bookingId: booking._id });
    res.json({ success: true, message: 'Booking deleted and dates unblocked' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ── All inquiries ─────────────────────────────────────────────
router.get('/inquiries', auth, async (req, res) => {
  try {
    const { status } = req.query;
    const query = status ? { status } : {};
    const inquiries = await Inquiry.find(query).sort({ createdAt: -1 }).limit(100).lean();
    // Mark as read
    if (!status || status === 'new') {
      await Inquiry.updateMany({ status: 'new' }, { status: 'read' });
    }
    res.json({ success: true, inquiries });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ── Update inquiry status ─────────────────────────────────────
router.patch('/inquiries/:id', auth, async (req, res) => {
  try {
    const inquiry = await Inquiry.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ success: true, inquiry });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ── Get all reviews (including unapproved) ───────────────────
router.get('/reviews', auth, async (req, res) => {
  try {
    const reviews = await Review.find().sort({ createdAt: -1 }).lean();
    res.json({ success: true, reviews });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ── Update review ─────────────────────────────────────────────
router.patch('/reviews/:id', auth, async (req, res) => {
  try {
    const review = await Review.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ success: true, review });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ── Delete review ─────────────────────────────────────────────
router.delete('/reviews/:id', auth, async (req, res) => {
  try {
    await Review.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: 'Review deleted' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ── Block dates manually ──────────────────────────────────────
router.post('/block-dates', auth, async (req, res) => {
  try {
    const { dates, reason = 'blocked', note = '' } = req.body;
    if (!Array.isArray(dates) || !dates.length)
      return res.status(400).json({ success: false, message: 'dates array required' });
    const docs = dates.map(d => ({ date: new Date(d), reason, note }));
    await BlockedDate.insertMany(docs, { ordered: false });
    res.json({ success: true, message: `${dates.length} date(s) blocked` });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ── Unblock dates ─────────────────────────────────────────────
router.delete('/block-dates', auth, async (req, res) => {
  try {
    const { dates } = req.body;
    if (!Array.isArray(dates) || !dates.length)
      return res.status(400).json({ success: false, message: 'dates array required' });
    const result = await BlockedDate.deleteMany({ date: { $in: dates.map(d => new Date(d)) } });
    res.json({ success: true, message: `${result.deletedCount} date(s) unblocked` });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ── Get all blocked dates ─────────────────────────────────────
router.get('/blocked-dates', auth, async (req, res) => {
  try {
    const { from, to } = req.query;
    const query = {};
    if (from || to) {
      query.date = {};
      if (from) query.date.$gte = new Date(from);
      if (to)   query.date.$lte = new Date(to);
    }
    const dates = await BlockedDate.find(query).sort({ date: 1 }).lean();
    res.json({ success: true, dates });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
