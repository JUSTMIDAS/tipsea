const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const Booking = require('../models/Booking');
const BlockedDate = require('../models/BlockedDate');
const { sendBookingConfirmationGuest, sendBookingAlertAdmin } = require('../middleware/mailer');

const validateBooking = [
  body('guestName').trim().notEmpty().withMessage('Name is required'),
  body('guestEmail').isEmail().normalizeEmail().withMessage('Valid email required'),
  body('guestPhone').trim().notEmpty().withMessage('Phone is required'),
  body('checkIn').isISO8601().withMessage('Valid check-in date required'),
  body('checkOut').isISO8601().withMessage('Valid check-out date required'),
  body('adults').isInt({ min: 1, max: 12 }).withMessage('Adults must be 1-12'),
];

// ── Check availability ───────────────────────────────────────
router.get('/check-availability', async (req, res) => {
  try {
    const { checkIn, checkOut } = req.query;
    if (!checkIn || !checkOut)
      return res.status(400).json({ success: false, message: 'Dates required' });

    const startDate = new Date(checkIn);
    const endDate   = new Date(checkOut);

    if (isNaN(startDate) || isNaN(endDate))
      return res.status(400).json({ success: false, message: 'Invalid dates' });

    const blockedDates = await BlockedDate.find({ date: { $gte: startDate, $lt: endDate } });
    const available    = blockedDates.length === 0;
    const nights       = Math.ceil((endDate - startDate) / 86400000);

    // Peak season: Dec–Apr
    const peakMonths = [12, 1, 2, 3, 4];
    const month = startDate.getMonth() + 1;
    const rate  = peakMonths.includes(month) ? 1500 : 1200;

    res.json({
      success: true,
      available,
      nights,
      pricePerNight: rate,
      totalPrice: available ? nights * rate : null,
      blockedDates: blockedDates.map(d => d.date.toISOString().split('T')[0]),
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ── Create booking ───────────────────────────────────────────
router.post('/', validateBooking, async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty())
    return res.status(400).json({ success: false, errors: errors.array() });

  try {
    const { checkIn, checkOut } = req.body;
    const startDate = new Date(checkIn);
    const endDate   = new Date(checkOut);

    if (startDate >= endDate)
      return res.status(400).json({ success: false, message: 'Check-out must be after check-in' });

    if (startDate < new Date(new Date().toDateString()))
      return res.status(400).json({ success: false, message: 'Cannot book past dates' });

    const nights = Math.ceil((endDate - startDate) / 86400000);
    if (nights < 5)
      return res.status(400).json({ success: false, message: 'Minimum stay is 5 nights' });

    // Conflict check
    const conflicts = await BlockedDate.find({ date: { $gte: startDate, $lt: endDate } });
    if (conflicts.length > 0)
      return res.status(409).json({ success: false, message: 'Selected dates are unavailable. Please choose different dates.' });

    // Determine rate
    const peakMonths = [12, 1, 2, 3, 4];
    const month = startDate.getMonth() + 1;
    const pricePerNight = peakMonths.includes(month) ? 1500 : 1200;

    const booking = new Booking({ ...req.body, pricePerNight });
    await booking.save();

    // Block the dates
    const datesToBlock = [];
    const cur = new Date(startDate);
    while (cur < endDate) {
      datesToBlock.push({ date: new Date(cur), reason: 'booked', bookingId: booking._id });
      cur.setDate(cur.getDate() + 1);
    }
    await BlockedDate.insertMany(datesToBlock, { ordered: false });

    // Fire emails (non-blocking)
    sendBookingConfirmationGuest(booking).catch(e => console.error('Guest email err:', e.message));
    sendBookingAlertAdmin(booking).catch(e => console.error('Admin email err:', e.message));

    res.status(201).json({
      success: true,
      message: 'Reservation request received! We\'ll confirm within 24 hours.',
      booking: {
        confirmationCode: booking.confirmationCode,
        checkIn:    booking.checkIn,
        checkOut:   booking.checkOut,
        totalNights: booking.totalNights,
        totalPrice:  booking.totalPrice,
        status:      booking.status,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ── Look up by confirmation code ─────────────────────────────
router.get('/confirm/:code', async (req, res) => {
  try {
    const booking = await Booking.findOne({
      confirmationCode: req.params.code.toUpperCase(),
    }).select('-adminNotes');
    if (!booking)
      return res.status(404).json({ success: false, message: 'Booking not found' });
    res.json({ success: true, booking });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
