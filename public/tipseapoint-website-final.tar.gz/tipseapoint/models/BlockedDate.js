const mongoose = require('mongoose');

const blockedDateSchema = new mongoose.Schema({
  date: { type: Date, required: true, unique: true },
  reason: { type: String, enum: ['booked', 'maintenance', 'owner', 'blocked'], default: 'booked' },
  bookingId: { type: mongoose.Schema.Types.ObjectId, ref: 'Booking' },
  note: { type: String },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('BlockedDate', blockedDateSchema);
