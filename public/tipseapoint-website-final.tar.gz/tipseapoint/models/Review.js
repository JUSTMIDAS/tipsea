const mongoose = require('mongoose');

const reviewSchema = new mongoose.Schema({
  guestName: { type: String, required: true, trim: true },
  guestLocation: { type: String, trim: true },
  rating: { type: Number, required: true, min: 1, max: 5 },
  title: { type: String, trim: true },
  content: { type: String, required: true, trim: true },
  stayDate: { type: Date },
  approved: { type: Boolean, default: false },
  featured: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Review', reviewSchema);
