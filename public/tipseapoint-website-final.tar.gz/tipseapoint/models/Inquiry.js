const mongoose = require('mongoose');

const inquirySchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, lowercase: true, trim: true },
  phone: { type: String, trim: true },
  subject: { type: String, trim: true },
  message: { type: String, required: true, trim: true },
  preferredCheckIn: { type: Date },
  preferredCheckOut: { type: Date },
  guests: { type: Number, default: 2 },
  status: { type: String, enum: ['new', 'read', 'replied', 'archived'], default: 'new' },
  source: { type: String, default: 'contact-form' },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Inquiry', inquirySchema);
