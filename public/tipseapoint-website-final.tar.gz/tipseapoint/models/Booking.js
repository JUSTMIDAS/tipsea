const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
  guestName: { type: String, required: true, trim: true },
  guestEmail: { type: String, required: true, lowercase: true, trim: true },
  guestPhone: { type: String, required: true, trim: true },
  guestCountry: { type: String, trim: true },
  checkIn: { type: Date, required: true },
  checkOut: { type: Date, required: true },
  adults: { type: Number, required: true, min: 1, max: 12 },
  children: { type: Number, default: 0, min: 0 },
  totalNights: { type: Number },
  totalPrice: { type: Number },
  pricePerNight: { type: Number, default: 1200 },
  status: {
    type: String,
    enum: ['pending', 'confirmed', 'cancelled', 'completed'],
    default: 'pending'
  },
  specialRequests: { type: String, trim: true },
  source: { type: String, default: 'website' },
  confirmationCode: { type: String, unique: true },
  paymentStatus: {
    type: String,
    enum: ['unpaid', 'deposit_paid', 'fully_paid'],
    default: 'unpaid'
  },
  adminNotes: { type: String },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

bookingSchema.pre('save', function(next) {
  if (this.checkIn && this.checkOut) {
    const diff = Math.abs(this.checkOut - this.checkIn);
    this.totalNights = Math.ceil(diff / (1000 * 60 * 60 * 24));
    this.totalPrice = this.totalNights * this.pricePerNight;
  }
  if (!this.confirmationCode) {
    this.confirmationCode = 'TSP-' + Date.now().toString(36).toUpperCase();
  }
  this.updatedAt = new Date();
  next();
});

module.exports = mongoose.model('Booking', bookingSchema);
