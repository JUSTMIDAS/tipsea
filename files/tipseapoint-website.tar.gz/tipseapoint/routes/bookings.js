const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const Booking = require('../models/Booking');
const BlockedDate = require('../models/BlockedDate');

const validateBooking = [
  body('guestName').trim().notEmpty().withMessage('Name is required'),
  body('guestEmail').isEmail().normalizeEmail().withMessage('Valid email required'),
  body('guestPhone').trim().notEmpty().withMessage('Phone is required'),
  body('checkIn').isISO8601().withMessage('Valid check-in date required'),
  body('checkOut').isISO8601().withMessage('Valid check-out date required'),
  body('adults').isInt({ min: 1, max: 12 }).withMessage('Adults must be 1-12'),
];

// Check availability for date range
router.get('/check-availability', async (req, res) => {
  try {
    const { checkIn, checkOut } = req.query;
    if (!checkIn || !checkOut) {
      return res.status(400).json({ success: false, message: 'Dates required' });
    }

    const startDate = new Date(checkIn);
    const endDate = new Date(checkOut);

    const blockedDates = await BlockedDate.find({
      date: { $gte: startDate, $lt: endDate }
    });

    const available = blockedDates.length === 0;
    const nights = Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24));

    res.json({
      success: true,
      available,
      nights,
      totalPrice: available ? nights * 1200 : null,
      pricePerNight: 1200,
      blockedDates: blockedDates.map(d => d.date)
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Create booking
router.post('/', validateBooking, async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }

  try {
    const { checkIn, checkOut } = req.body;
    const startDate = new Date(checkIn);
    const endDate = new Date(checkOut);

    if (startDate >= endDate) {
      return res.status(400).json({ success: false, message: 'Check-out must be after check-in' });
    }

    if (startDate < new Date()) {
      return res.status(400).json({ success: false, message: 'Cannot book past dates' });
    }

    // Check for conflicts
    const conflictingDates = await BlockedDate.find({
      date: { $gte: startDate, $lt: endDate }
    });

    if (conflictingDates.length > 0) {
      return res.status(409).json({ success: false, message: 'Selected dates are not available' });
    }

    const booking = new Booking(req.body);
    await booking.save();

    // Block the dates
    const datesToBlock = [];
    const current = new Date(startDate);
    while (current < endDate) {
      datesToBlock.push({ date: new Date(current), reason: 'booked', bookingId: booking._id });
      current.setDate(current.getDate() + 1);
    }

    await BlockedDate.insertMany(datesToBlock, { ordered: false });

    res.status(201).json({
      success: true,
      message: 'Booking request received! We will confirm within 24 hours.',
      booking: {
        confirmationCode: booking.confirmationCode,
        checkIn: booking.checkIn,
        checkOut: booking.checkOut,
        totalNights: booking.totalNights,
        totalPrice: booking.totalPrice,
        status: booking.status
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Get booking by confirmation code
router.get('/confirm/:code', async (req, res) => {
  try {
    const booking = await Booking.findOne({ confirmationCode: req.params.code });
    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found' });
    }
    res.json({ success: true, booking });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
