const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const path = require('path');
const Booking = require('../models/Booking');
const Inquiry = require('../models/Inquiry');
const Review = require('../models/Review');
const BlockedDate = require('../models/BlockedDate');

const JWT_SECRET = process.env.JWT_SECRET || 'tipseapoint-secret-2024';
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'admin@tipseapoint.com';
const ADMIN_PASS_HASH = process.env.ADMIN_PASS_HASH || bcrypt.hashSync('admin123', 10);

const authMiddleware = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ success: false, message: 'No token' });
  try {
    req.admin = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ success: false, message: 'Invalid token' });
  }
};

// Serve admin HTML
router.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'admin.html'));
});

// Login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (email !== ADMIN_EMAIL || !bcrypt.compareSync(password, ADMIN_PASS_HASH)) {
    return res.status(401).json({ success: false, message: 'Invalid credentials' });
  }
  const token = jwt.sign({ email, role: 'admin' }, JWT_SECRET, { expiresIn: '24h' });
  res.json({ success: true, token });
});

// Stats
router.get('/stats', authMiddleware, async (req, res) => {
  try {
    const [totalBookings, pendingBookings, totalInquiries, newInquiries, pendingReviews] = await Promise.all([
      Booking.countDocuments(),
      Booking.countDocuments({ status: 'pending' }),
      Inquiry.countDocuments(),
      Inquiry.countDocuments({ status: 'new' }),
      Review.countDocuments({ approved: false }),
    ]);
    const recentBookings = await Booking.find().sort({ createdAt: -1 }).limit(5);
    const revenue = await Booking.aggregate([
      { $match: { status: { $in: ['confirmed', 'completed'] } } },
      { $group: { _id: null, total: { $sum: '$totalPrice' } } }
    ]);
    res.json({ success: true, stats: { totalBookings, pendingBookings, totalInquiries, newInquiries, pendingReviews, totalRevenue: revenue[0]?.total || 0, recentBookings } });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// All bookings
router.get('/bookings', authMiddleware, async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const query = status ? { status } : {};
    const bookings = await Booking.find(query).sort({ createdAt: -1 }).limit(Number(limit)).skip((Number(page) - 1) * Number(limit));
    const total = await Booking.countDocuments(query);
    res.json({ success: true, bookings, total, page, pages: Math.ceil(total / limit) });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// Update booking
router.patch('/bookings/:id', authMiddleware, async (req, res) => {
  try {
    const booking = await Booking.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!booking) return res.status(404).json({ success: false, message: 'Not found' });
    res.json({ success: true, booking });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// All inquiries
router.get('/inquiries', authMiddleware, async (req, res) => {
  try {
    const inquiries = await Inquiry.find().sort({ createdAt: -1 }).limit(100);
    res.json({ success: true, inquiries });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// Update inquiry
router.patch('/inquiries/:id', authMiddleware, async (req, res) => {
  try {
    const inquiry = await Inquiry.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ success: true, inquiry });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// All reviews (incl. unapproved)
router.get('/reviews', authMiddleware, async (req, res) => {
  try {
    const reviews = await Review.find().sort({ createdAt: -1 });
    res.json({ success: true, reviews });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// Update review
router.patch('/reviews/:id', authMiddleware, async (req, res) => {
  try {
    const review = await Review.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ success: true, review });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// Delete review
router.delete('/reviews/:id', authMiddleware, async (req, res) => {
  try {
    await Review.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: 'Deleted' });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// Block dates
router.post('/block-dates', authMiddleware, async (req, res) => {
  try {
    const { dates, reason, note } = req.body;
    const docs = dates.map(d => ({ date: new Date(d), reason: reason || 'blocked', note }));
    await BlockedDate.insertMany(docs, { ordered: false });
    res.json({ success: true, message: `${dates.length} date(s) blocked` });
  } catch (err) {
    res.json({ success: true, message: 'Dates updated (some may already be blocked)' });
  }
});

// Unblock dates
router.delete('/block-dates', authMiddleware, async (req, res) => {
  try {
    const { dates } = req.body;
    await BlockedDate.deleteMany({ date: { $in: dates.map(d => new Date(d)) } });
    res.json({ success: true, message: `${dates.length} date(s) unblocked` });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

module.exports = router;
